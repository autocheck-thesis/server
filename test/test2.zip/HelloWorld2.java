class HelloWorld {
  public static void main(String[] args) {
    System.out.println(getString());
  }

  public static String getString() {
    return "I'm in Java";
  }
}