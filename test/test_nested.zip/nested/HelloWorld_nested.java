class HelloWorld_nested {
	public static void main(String[] args) {
		System.out.println("I'm in Java now too");
	}
}

